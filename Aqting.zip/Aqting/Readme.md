# 🎬 AQTING Platform - Video Learning Management System

Platform pembelajaran video editing yang modern dan profesional dengan fitur manajemen konten lengkap.

## ✨ Fitur Utama

### 🎓 Untuk Pengguna
- **Video Library** - Akses semua materi video editing
- **Filter Berdasarkan Bulan** - Organisasi konten yang rapi
- **Sistem Komentar** - Interaksi dan diskusi pada setiap video
- **Banner Carousel** - Informasi promo dan event terbaru
- **Responsive Design** - Optimal di semua perangkat
- **Video Player** - Support YouTube embed dan video direct

### 🎛️ Admin Panel
- **Manajemen Materi** - Tambah, edit, hapus video
- **Manajemen Banner** - Upload dan kelola banner carousel (ukuran Instagram 1:1)
- **Manajemen Komentar** - Moderasi komentar pengguna
- **Upload File** - Upload banner langsung ke Firebase Storage
- **Analytics** - Track visitor dan engagement
- **Secure Login** - Sistem login dengan rate limiting

## 🚀 Teknologi

### Frontend
- **EJS** - Template engine
- **Vanilla JavaScript** - Modular architecture
- **CSS3** - Modern styling dengan animations

### Backend
- **Express.js** - Web framework
- **Node.js** - Runtime environment

### Database & Storage
- **Firebase Realtime Database** - Data storage
- **Firebase Storage** - File hosting untuk banner

## 📦 Instalasi

### Prerequisites
- Node.js v14+ 
- npm atau yarn

### Setup

1. **Clone repository**
```bash
git clone <repository-url>
cd aqting-platform
```

2. **Install dependencies**
```bash
npm install
```

3. **Struktur Folder**
```
aqting-platform/
├── server.js                 # Express server
├── package.json             # Dependencies
├── views/                   # EJS templates
│   ├── index.ejs           # Main page
│   ├── 404.ejs             # Error page
│   └── partials/           # Reusable components
│       ├── admin-panel.ejs
│       └── video-modal.ejs
└── public/                  # Static files
    ├── css/
    │   └── style.css       # Main stylesheet
    └── js/
        ├── firebase-config.js  # Firebase setup
        ├── banner.js          # Banner management
        ├── courses.js         # Course management
        ├── comments.js        # Comments system
        ├── admin.js           # Admin functions
        └── main.js            # App initialization
```

4. **Konfigurasi Firebase**
Edit `public/js/firebase-config.js` dengan kredensial Firebase Anda:
```javascript
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    databaseURL: "YOUR_DATABASE_URL",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};
```

5. **Ubah Admin Password**
Edit password admin di `public/js/firebase-config.js`:
```javascript
const ADMIN_PASSWORD = 'your_secure_password_here';
```

6. **Jalankan aplikasi**
```bash
# Development
npm run dev

# Production
npm start
```

7. **Akses aplikasi**
```
http://localhost:3000
```

## 🎨 Fitur Banner

### Spesifikasi Banner
- **Ukuran**: 1080x1080px (Instagram Post)
- **Rasio**: 1:1 (Square)
- **Format**: JPG, PNG, WebP
- **Ukuran File**: Maksimal 5MB
- **Carousel**: Auto-play setiap 5 detik

### Cara Menambah Banner
1. Login ke Admin Panel
2. Pilih tab "🖼️ Kelola Banner"
3. Isi form:
   - **Judul Banner** - Nama/deskripsi banner
   - **URL Gambar** - Link gambar atau upload file
   - **CTA URL** - Link tujuan saat banner diklik
   - **Status** - Aktif/Nonaktif
4. Klik "➕ Tambah Banner"

### Upload File Banner
- Gunakan tombol "Upload File Banner"
- Pilih gambar dari komputer
- Progress upload akan ditampilkan
- URL otomatis terisi setelah upload berhasil

## 🔐 Admin Panel

### Akses Admin
1. Klik tombol "🔐 Admin Panel"
2. Masukkan password admin
3. Akses fitur manajemen

### Fitur Admin
- **➕ Tambah Materi** - Upload video baru
- **📚 Kelola Materi** - Edit/hapus video
- **🖼️ Kelola Banner** - Manajemen banner carousel
- **💬 Kelola Komentar** - Moderasi komentar

## 🛡️ Keamanan

- **Rate Limiting** - Maksimal 3 percobaan login
- **Auto Block** - Block 5 menit setelah gagal 3x
- **Secure Password** - Password kompleks dan panjang
- **Input Validation** - Validasi semua input user
- **XSS Protection** - HTML escaping pada komentar

## 🎯 Best Practices

### Manajemen Konten
- Gunakan emoji yang konsisten untuk setiap kategori
- Buat thumbnail menarik untuk video
- Tulis deskripsi yang jelas dan informatif
- Organisasi berdasarkan bulan untuk kemudahan navigasi

### Banner Design
- Gunakan gambar berkualitas tinggi
- Pastikan teks pada banner mudah dibaca
- Gunakan call-to-action yang jelas
- Test responsiveness di berbagai device

### Performance
- Compress gambar sebelum upload
- Gunakan format WebP untuk efisiensi
- Optimalkan video (YouTube embed lebih baik)
- Monitor Firebase usage

## 📱 Responsive Design

Platform fully responsive untuk:
- 📱 Mobile (320px - 768px)
- 💻 Tablet (768px - 1024px)
- 🖥️ Desktop (1024px+)

## 🐛 Troubleshooting

### Firebase Error
```
Error: Firebase not initialized
```
**Solusi**: Cek konfigurasi Firebase di `firebase-config.js`

### Upload Banner Gagal
```
Error: Upload failed
```
**Solusi**: 
- Cek ukuran file (max 5MB)
- Pastikan format gambar valid
- Cek Firebase Storage rules

### Video Tidak Muncul
**Solusi**:
- Pastikan URL video benar
- Untuk YouTube: gunakan embed URL
- Untuk direct video: pastikan CORS enabled

## 📝 Changelog

### Version 2.0.0 (Current)
- ✅ Migrasi ke Express.js architecture
- ✅ Modular JavaScript structure
- ✅ Banner carousel system
- ✅ File upload untuk banner
- ✅ Improved UI/UX
- ✅ Better security
- ✅ Enhanced admin panel

### Version 1.0.0
- Initial release dengan HTML standalone

## 👥 Kontribusi

Kontribusi sangat diterima! Silakan:
1. Fork repository
2. Buat branch baru (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

## 📄 License

MIT License - bebas digunakan untuk proyek personal maupun komersial

## 🙏 Credits

Dibuat dengan ❤️ untuk AQTING Community

---

**Need Help?** Hubungi tim support atau buka issue di repository.