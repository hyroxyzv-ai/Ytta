// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBakjlWu0_PCfJYNJRsNScmpD1bJVQetMU",
    authDomain: "aqting-aqal.firebaseapp.com",
    databaseURL: "https://aqting-aqal-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "aqting-aqal",
    storageBucket: "aqting-aqal.firebasestorage.app",
    messagingSenderId: "135142655439",
    appId: "1:135142655439:web:f837fc608ab3504713beba"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();
const storage = firebase.storage();

// Admin Password
const ADMIN_PASSWORD = 'h9Q3kax1SI7WCscwF6ELAXfG8vJMTOju0HgVNPr4KdiBU5lm2RDntpeobqGRFJEJ2SPv1DTwj3oPnkBfQDL57rRq77uNxMQinjla';

// Global Variables
let loginAttempts = 0;
let isBlocked = false;
let isAdminLoggedIn = false;
let courses = [];
let comments = {};
let banners = [];
let selectedMonth = 'all';

console.log('✅ Firebase initialized');