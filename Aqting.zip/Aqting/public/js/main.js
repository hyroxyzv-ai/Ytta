// Main Application Initialization
function initializeApp() {
    console.log('🚀 Initializing AQTING Platform...');
    
    loadCourses();
    loadComments();
    loadBanners();
    trackVisitor();
    
    setupEventListeners();
    
    console.log('✅ AQTING Platform Loaded Successfully');
}

// Setup Event Listeners
function setupEventListeners() {
    // Escape key to close modals
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const videoModal = document.getElementById('videoModal');
            const adminPanel = document.getElementById('adminPanel');
            
            if (videoModal.classList.contains('active')) {
                closeModal();
            }
            if (adminPanel.classList.contains('active') && !isAdminLoggedIn) {
                toggleAdminPanel();
            }
        }
        
        // Enter key on password input
        if (e.key === 'Enter' && document.activeElement.id === 'adminPassword') {
            loginAdmin();
        }
    });

    // Click outside modal to close
    document.getElementById('videoModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });

    // Click outside admin panel to close (only if not logged in)
    document.getElementById('adminPanel').addEventListener('click', function(e) {
        if (e.target === this && !isAdminLoggedIn) {
            toggleAdminPanel();
        }
    });

    // Prevent default form submissions
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
        });
    });

    // Add smooth scroll behavior
    document.documentElement.style.scrollBehavior = 'smooth';
}

// Utility Functions
function formatDate(date) {
    return new Date(date).toLocaleString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#28a745' : '#dc3545'};
        color: white;
        padding: 15px 25px;
        border-radius: 12px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animation keyframes
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// Service Worker Registration (optional for PWA)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(reg => console.log('✅ Service Worker registered'))
            .catch(err => console.log('❌ Service Worker registration failed'));
    });
}

console.log('✅ Main app script loaded');