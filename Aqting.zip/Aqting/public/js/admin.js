// Admin Panel Management
function toggleAdminPanel() {
    const panel = document.getElementById('adminPanel');
    const isActive = panel.classList.contains('active');
    
    if (isActive) {
        panel.classList.remove('active');
        document.body.style.overflow = 'auto';
    } else {
        panel.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function loginAdmin() {
    if (isBlocked) {
        alert('🚫 Login diblokir. Tunggu beberapa menit.');
        return;
    }
    
    const password = document.getElementById('adminPassword').value;
    const loginBtn = document.getElementById('loginBtn');
    
    loginBtn.innerHTML = '<span class="loading-spinner"></span> Memverifikasi...';
    loginBtn.disabled = true;
    
    setTimeout(() => {
        if (password === ADMIN_PASSWORD) {
            isAdminLoggedIn = true;
            loginAttempts = 0;
            document.getElementById('loginSection').style.display = 'none';
            document.getElementById('adminContent').style.display = 'block';
            updateSessionInfo();
            
            // Load admin data
            renderAdminCourseList();
            renderAdminBanners();
            renderAdminComments();
        } else {
            loginAttempts++;
            if (loginAttempts >= 3) {
                isBlocked = true;
                alert('🚫 Terlalu banyak percobaan gagal! Login diblokir selama 5 menit.');
                setTimeout(() => { 
                    isBlocked = false; 
                    loginAttempts = 0; 
                }, 300000);
            } else {
                alert(`❌ Password salah! Sisa percobaan: ${3 - loginAttempts}x`);
            }
            document.getElementById('adminPassword').value = '';
        }
        loginBtn.innerHTML = 'Login';
        loginBtn.disabled = false;
    }, 1000);
}

function updateSessionInfo() {
    const sessionInfo = document.getElementById('sessionInfo');
    sessionInfo.innerHTML = `
        <div class="session-info">
            <span>🔐 Sesi admin aktif</span>
            <button class="btn-logout" onclick="logoutAdmin()">Logout</button>
        </div>
    `;
}

function logoutAdmin() {
    if (!confirm('⚠️ Yakin ingin logout?')) return;
    
    isAdminLoggedIn = false;
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('adminContent').style.display = 'none';
    document.getElementById('adminPassword').value = '';
    
    // Reset to first tab
    switchTab('addCourse');
}

function switchTab(tabName) {
    // Remove active from all tabs and contents
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.admin-tab').forEach(btn => btn.classList.remove('active'));
    
    // Add active to selected
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');

    // Load content for specific tabs
    if (tabName === 'manageCourses') renderAdminCourseList();
    if (tabName === 'manageBanners') renderAdminBanners();
    if (tabName === 'manageComments') renderAdminComments();
}

// Track visitor analytics
function trackVisitor() {
    const visitorsRef = database.ref('analytics/visitors');
    visitorsRef.transaction((current) => (current || 0) + 1);
    
    // Track page visit
    const visitsRef = database.ref('analytics/visits');
    visitsRef.push({
        timestamp: Date.now(),
        date: new Date().toLocaleString('id-ID'),
        userAgent: navigator.userAgent
    });
}

console.log('✅ Admin module loaded');