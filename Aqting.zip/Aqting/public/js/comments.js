// Comments Management
function loadComments() {
    const commentsRef = database.ref('comments');
    commentsRef.on('value', (snapshot) => {
        const data = snapshot.val();
        if (data) comments = data;
    });
}

function addComment() {
    const name = document.getElementById('nameInput').value.trim();
    const text = document.getElementById('commentInput').value.trim();
    
    if (!name || !text) {
        alert('⚠️ Silakan isi nama dan komentar');
        return;
    }

    if (text.length > 500) {
        alert('⚠️ Komentar maksimal 500 karakter');
        return;
    }

    const courseId = window.currentCourseId;
    const newComment = {
        author: name,
        text: text,
        time: new Date().toLocaleString('id-ID'),
        timestamp: Date.now()
    };

    database.ref('comments/' + courseId).push(newComment).then(() => {
        document.getElementById('commentInput').value = '';
        document.getElementById('nameInput').value = '';
        alert('✅ Komentar berhasil ditambahkan!');
    }).catch((error) => {
        alert('❌ Gagal menambahkan komentar: ' + error.message);
    });
}

function renderComments(courseId) {
    const commentList = document.getElementById('commentList');
    const courseComments = comments[courseId];

    if (!courseComments) {
        commentList.innerHTML = '<div class="no-comments">💬 Belum ada komentar. Jadilah yang pertama berkomentar!</div>';
        return;
    }

    const commentsArray = Object.values(courseComments).sort((a, b) => b.timestamp - a.timestamp);

    commentList.innerHTML = commentsArray.map(comment => `
        <div class="comment-item">
            <div class="comment-author">${escapeHtml(comment.author)}</div>
            <div class="comment-time">${comment.time}</div>
            <div class="comment-text">${escapeHtml(comment.text)}</div>
        </div>
    `).join('');
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Admin Comment Functions
function deleteComment(courseId, commentKey) {
    if (!isAdminLoggedIn || !confirm('⚠️ Yakin hapus komentar ini?')) return;

    database.ref('comments/' + courseId + '/' + commentKey).remove().then(() => {
        alert('✅ Komentar berhasil dihapus!');
        renderAdminComments();
    }).catch((error) => {
        alert('❌ Gagal menghapus komentar: ' + error.message);
    });
}

function renderAdminComments() {
    const container = document.getElementById('adminCommentList');
    
    if (!comments || Object.keys(comments).length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #999; padding: 30px;">Belum ada komentar</p>';
        return;
    }

    let html = '';
    Object.keys(comments).forEach(courseId => {
        const course = courses.find(c => c.id == courseId);
        const courseTitle = course ? course.title : 'Unknown Course';
        const courseComments = comments[courseId];

        if (!courseComments) return;

        const commentCount = Object.keys(courseComments).length;

        html += `
            <div style="margin-bottom: 35px;">
                <h4 style="color: #00311e; margin-bottom: 15px; font-size: 1.2em;">
                    📹 ${courseTitle} <span style="color: #6c757d; font-size: 0.85em;">(${commentCount} komentar)</span>
                </h4>
                <div class="comment-list">
        `;

        Object.keys(courseComments).forEach(commentKey => {
            const comment = courseComments[commentKey];
            html += `
                <div class="comment-item" style="display: flex; justify-content: space-between; gap: 15px;">
                    <div style="flex: 1;">
                        <div class="comment-author">${escapeHtml(comment.author)}</div>
                        <div class="comment-time">${comment.time}</div>
                        <div class="comment-text">${escapeHtml(comment.text)}</div>
                    </div>
                    <button class="btn-danger" onclick="deleteComment('${courseId}', '${commentKey}')" 
                            style="align-self: flex-start;">🗑️</button>
                </div>
            `;
        });

        html += `</div></div>`;
    });

    container.innerHTML = html;
}

console.log('✅ Comments module loaded');