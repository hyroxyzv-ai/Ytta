// Banner Carousel Management
let currentBannerIndex = 0;
let bannerInterval;

function loadBanners() {
    const bannersRef = database.ref('banners');
    bannersRef.on('value', (snapshot) => {
        const data = snapshot.val();
        if (data) {
            banners = Object.entries(data)
                .map(([key, value]) => ({ id: key, ...value }))
                .filter(banner => banner.status === 'active')
                .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
            
            if (banners.length > 0) {
                renderBannerCarousel();
                startBannerAutoplay();
            } else {
                hideBannerCarousel();
            }
        } else {
            hideBannerCarousel();
        }
    });
}

function renderBannerCarousel() {
    const carousel = document.getElementById('bannerCarousel');
    const track = document.getElementById('bannerTrack');
    const controls = document.getElementById('bannerControls');

    if (banners.length === 0) {
        hideBannerCarousel();
        return;
    }

    carousel.style.display = 'block';

    // Render slides
    track.innerHTML = banners.map((banner, index) => `
        <div class="banner-slide" onclick="handleBannerClick('${banner.ctaUrl}')">
            <img src="${banner.imageUrl}" alt="${banner.title}" class="banner-image">
        </div>
    `).join('');

    // Render controls (dots)
    if (banners.length > 1) {
        controls.innerHTML = banners.map((_, index) => `
            <div class="banner-dot ${index === 0 ? 'active' : ''}" onclick="goToBanner(${index})"></div>
        `).join('');
    }

    currentBannerIndex = 0;
    updateBannerPosition();
}

function hideBannerCarousel() {
    const carousel = document.getElementById('bannerCarousel');
    carousel.style.display = 'none';
    stopBannerAutoplay();
}

function updateBannerPosition() {
    const track = document.getElementById('bannerTrack');
    track.style.transform = `translateX(-${currentBannerIndex * 100}%)`;

    // Update dots
    document.querySelectorAll('.banner-dot').forEach((dot, index) => {
        dot.classList.toggle('active', index === currentBannerIndex);
    });
}

function nextBanner() {
    currentBannerIndex = (currentBannerIndex + 1) % banners.length;
    updateBannerPosition();
    resetBannerAutoplay();
}

function prevBanner() {
    currentBannerIndex = (currentBannerIndex - 1 + banners.length) % banners.length;
    updateBannerPosition();
    resetBannerAutoplay();
}

function goToBanner(index) {
    currentBannerIndex = index;
    updateBannerPosition();
    resetBannerAutoplay();
}

function startBannerAutoplay() {
    if (banners.length > 1) {
        bannerInterval = setInterval(nextBanner, 5000);
    }
}

function stopBannerAutoplay() {
    if (bannerInterval) {
        clearInterval(bannerInterval);
    }
}

function resetBannerAutoplay() {
    stopBannerAutoplay();
    startBannerAutoplay();
}

function handleBannerClick(ctaUrl) {
    if (ctaUrl && ctaUrl.trim() !== '') {
        window.open(ctaUrl, '_blank');
    }
}

// Admin Banner Functions
function handleBannerFileUpload() {
    const fileInput = document.getElementById('bannerFileInput');
    const file = fileInput.files[0];
    
    if (!file) return;

    // Validate file
    if (!file.type.startsWith('image/')) {
        alert('❌ Hanya file gambar yang diperbolehkan!');
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        alert('❌ Ukuran file maksimal 5MB!');
        return;
    }

    // Show progress
    document.getElementById('uploadProgress').style.display = 'block';
    document.getElementById('uploadProgressBar').style.width = '0%';
    document.getElementById('uploadProgressText').textContent = 'Uploading...';

    // Upload to Firebase Storage
    const storageRef = storage.ref('banners/' + Date.now() + '_' + file.name);
    const uploadTask = storageRef.put(file);

    uploadTask.on('state_changed',
        (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            document.getElementById('uploadProgressBar').style.width = progress + '%';
            document.getElementById('uploadProgressText').textContent = `Uploading... ${Math.round(progress)}%`;
        },
        (error) => {
            console.error('Upload error:', error);
            alert('❌ Upload gagal: ' + error.message);
            document.getElementById('uploadProgress').style.display = 'none';
        },
        () => {
            uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
                document.getElementById('newBannerImage').value = downloadURL;
                document.getElementById('uploadProgressText').textContent = '✅ Upload berhasil!';
                
                // Show preview
                showBannerPreview(downloadURL);
                
                setTimeout(() => {
                    document.getElementById('uploadProgress').style.display = 'none';
                }, 2000);
            });
        }
    );
}

function showBannerPreview(imageUrl) {
    const preview = document.getElementById('bannerPreview');
    const previewImage = document.getElementById('bannerPreviewImage');
    
    previewImage.src = imageUrl;
    preview.style.display = 'block';
}

// Listen for image URL changes
document.addEventListener('DOMContentLoaded', () => {
    const imageInput = document.getElementById('newBannerImage');
    if (imageInput) {
        imageInput.addEventListener('input', (e) => {
            const url = e.target.value.trim();
            if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
                showBannerPreview(url);
            }
        });
    }
});

function addNewBanner() {
    if (!isAdminLoggedIn) {
        alert('❌ Login terlebih dahulu!');
        return;
    }

    const title = document.getElementById('newBannerTitle').value.trim();
    const imageUrl = document.getElementById('newBannerImage').value.trim();
    const ctaUrl = document.getElementById('newBannerCta').value.trim();
    const status = document.getElementById('newBannerStatus').value;

    if (!title || !imageUrl) {
        alert('❌ Judul dan gambar banner harus diisi!');
        return;
    }

    const newBanner = {
        title,
        imageUrl,
        ctaUrl,
        status,
        timestamp: Date.now(),
        createdAt: new Date().toLocaleString('id-ID')
    };

    database.ref('banners').push(newBanner).then(() => {
        // Clear form
        document.getElementById('newBannerTitle').value = '';
        document.getElementById('newBannerImage').value = '';
        document.getElementById('newBannerCta').value = '';
        document.getElementById('newBannerStatus').value = 'active';
        document.getElementById('bannerPreview').style.display = 'none';
        document.getElementById('bannerFileInput').value = '';

        alert('✅ Banner berhasil ditambahkan!');
        renderAdminBanners();
    }).catch((error) => {
        alert('❌ Gagal menambahkan banner: ' + error.message);
    });
}

function deleteBanner(bannerId) {
    if (!isAdminLoggedIn || !confirm('⚠️ Yakin hapus banner ini?')) return;

    database.ref('banners/' + bannerId).remove().then(() => {
        alert('✅ Banner berhasil dihapus!');
        renderAdminBanners();
    }).catch((error) => {
        alert('❌ Gagal menghapus banner: ' + error.message);
    });
}

function toggleBannerStatus(bannerId, currentStatus) {
    if (!isAdminLoggedIn) return;

    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    
    database.ref('banners/' + bannerId + '/status').set(newStatus).then(() => {
        alert(`✅ Status banner diubah menjadi ${newStatus === 'active' ? 'Aktif' : 'Nonaktif'}!`);
        renderAdminBanners();
    }).catch((error) => {
        alert('❌ Gagal mengubah status: ' + error.message);
    });
}

function renderAdminBanners() {
    const container = document.getElementById('adminBannerList');
    
    database.ref('banners').once('value', (snapshot) => {
        const data = snapshot.val();
        
        if (!data) {
            container.innerHTML = '<p style="text-align: center; color: #999; padding: 30px;">Belum ada banner</p>';
            return;
        }

        const bannersArray = Object.entries(data).map(([key, value]) => ({ id: key, ...value }));
        bannersArray.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

        container.innerHTML = bannersArray.map(banner => `
            <div class="banner-item">
                <div class="banner-item-info" style="display: flex; gap: 20px; align-items: center; flex: 1;">
                    <img src="${banner.imageUrl}" alt="${banner.title}" 
                         style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px;">
                    <div>
                        <h4>🖼️ ${banner.title}</h4>
                        <p>📅 ${banner.createdAt || 'N/A'}</p>
                        <p style="font-size: 0.85em;">
                            Status: <strong style="color: ${banner.status === 'active' ? '#28a745' : '#dc3545'}">
                                ${banner.status === 'active' ? '✅ Aktif' : '❌ Nonaktif'}
                            </strong>
                        </p>
                        ${banner.ctaUrl ? `<p style="font-size: 0.85em;">🔗 CTA: ${banner.ctaUrl}</p>` : ''}
                    </div>
                </div>
                <div class="banner-actions">
                    <button class="btn-primary" onclick="toggleBannerStatus('${banner.id}', '${banner.status}')" 
                            style="padding: 8px 16px; font-size: 0.9em;">
                        ${banner.status === 'active' ? '👁️ Sembunyikan' : '✅ Aktifkan'}
                    </button>
                    <button class="btn-danger" onclick="deleteBanner('${banner.id}')">🗑️ Hapus</button>
                </div>
            </div>
        `).join('');
    });
}

console.log('✅ Banner module loaded');