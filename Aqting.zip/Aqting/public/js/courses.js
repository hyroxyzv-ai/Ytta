// Courses Management
function loadCourses() {
    const coursesRef = database.ref('courses');
    coursesRef.on('value', (snapshot) => {
        const data = snapshot.val();
        if (data) {
            courses = Object.values(data);
        } else {
            courses = [
                {
                    id: 1,
                    title: 'Frame Freeze',
                    description: 'Belajar teknik membekukan frame di Spring',
                    videoUrl: 'https://files.catbox.moe/i8p93g.mp4',
                    duration: '4:34',
                    level: 'Spring',
                    icon: '🎥',
                    month: 'Oktober 2025',
                    uploadTime: '19 Okt 2025, 21:45'
                }
            ];
        }
        renderCourses();
        renderMonthButtons();
    });
}

function renderMonthButtons() {
    const months = [...new Set(courses.map(c => c.month))];
    const container = document.getElementById('monthButtons');
    container.innerHTML = `
        <button class="month-btn ${selectedMonth === 'all' ? 'active' : ''}" onclick="filterByMonth('all')">📚 Semua</button>
        ${months.map(m => `<button class="month-btn ${selectedMonth === m ? 'active' : ''}" onclick="filterByMonth('${m}')">${m}</button>`).join('')}
    `;
}

function filterByMonth(month) {
    selectedMonth = month;
    renderMonthButtons();
    renderCourses();
}

function renderCourses() {
    const filtered = selectedMonth === 'all' ? courses : courses.filter(c => c.month === selectedMonth);
    const container = document.getElementById('courseContainer');
    
    if (filtered.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 80px 20px; color: #6c757d;"><h3 style="margin-bottom: 10px;">📚 Belum ada materi</h3><p>Materi akan segera ditambahkan</p></div>';
        return;
    }

    const grouped = {};
    filtered.forEach(course => {
        if (!grouped[course.month]) grouped[course.month] = [];
        grouped[course.month].push(course);
    });

    container.innerHTML = Object.keys(grouped).map(month => `
        <div class="course-section">
            <div class="section-header">
                <div class="section-title">📅 ${month}</div>
                <div class="section-count">${grouped[month].length} Materi</div>
            </div>
            <div class="course-grid">
                ${grouped[month].map(course => `
                    <div class="course-card" onclick="openVideo(${course.id})">
                        <div class="course-thumbnail">
                            <div class="duration-badge">⏱️ ${course.duration}</div>
                            ${course.icon}
                        </div>
                        <div class="course-content">
                            <h3 class="course-title">${course.title}</h3>
                            <p class="course-description">${course.description}</p>
                            <div class="course-meta">
                                <div class="upload-time">🕒 ${course.uploadTime}</div>
                                <div class="course-info-row">
                                    <span class="level-badge">${course.level}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `).join('');
}

function openVideo(courseId) {
    const course = courses.find(c => c.id === courseId);
    if (!course) return;

    const modal = document.getElementById('videoModal');
    const videoContainer = document.getElementById('videoContainer');
    
    if (course.videoUrl.includes('.mp4') || course.videoUrl.includes('.webm')) {
        videoContainer.innerHTML = `
            <video controls style="width: 100%; height: 100%;">
                <source src="${course.videoUrl}" type="video/mp4">
            </video>
            <button class="fullscreen-btn" onclick="toggleFullscreen()">⛶</button>
        `;
    } else {
        videoContainer.innerHTML = `
            <iframe src="${course.videoUrl}" frameborder="0" allowfullscreen allow="autoplay; encrypted-media"></iframe>
            <button class="fullscreen-btn" onclick="toggleFullscreen()">⛶</button>
        `;
    }
    
    document.getElementById('modalTitle').textContent = course.title;
    document.getElementById('modalDescription').textContent = course.description;
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    window.currentCourseId = courseId;
    renderComments(courseId);
}

function closeModal() {
    const modal = document.getElementById('videoModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
    
    const videoContainer = document.getElementById('videoContainer');
    videoContainer.innerHTML = '<button class="fullscreen-btn" onclick="toggleFullscreen()">⛶</button>';
}

function toggleFullscreen() {
    const videoContainer = document.getElementById('videoContainer');
    if (!document.fullscreenElement) {
        videoContainer.requestFullscreen?.() || videoContainer.webkitRequestFullscreen?.();
    } else {
        document.exitFullscreen?.() || document.webkitExitFullscreen?.();
    }
}

// Admin Course Functions
function addNewCourse() {
    if (!isAdminLoggedIn) {
        alert('❌ Login terlebih dahulu!');
        return;
    }

    const title = document.getElementById('newTitle').value.trim();
    const description = document.getElementById('newDescription').value.trim();
    const videoUrl = document.getElementById('newVideoUrl').value.trim();
    const duration = document.getElementById('newDuration').value.trim();
    const level = document.getElementById('newLevel').value;
    const icon = document.getElementById('newIcon').value.trim();
    const month = document.getElementById('newMonth').value.trim();

    if (!title || !description || !videoUrl || !duration || !month) {
        alert('❌ Isi semua field yang diperlukan!');
        return;
    }

    const newId = courses.length > 0 ? Math.max(...courses.map(c => c.id)) + 1 : 1;
    const uploadTime = new Date().toLocaleString('id-ID');

    const newCourse = {
        id: newId,
        title, 
        description, 
        videoUrl, 
        duration, 
        level,
        icon: icon || '🎬',
        month, 
        uploadTime
    };

    database.ref('courses/' + newId).set(newCourse).then(() => {
        courses.push(newCourse);
        renderCourses();
        renderMonthButtons();
        
        // Clear form
        document.getElementById('newTitle').value = '';
        document.getElementById('newDescription').value = '';
        document.getElementById('newVideoUrl').value = '';
        document.getElementById('newDuration').value = '';
        document.getElementById('newIcon').value = '';
        document.getElementById('newMonth').value = '';

        alert('✅ Materi berhasil ditambahkan!');
    });
}

function deleteCourse(courseId) {
    if (!isAdminLoggedIn || !confirm('⚠️ Yakin hapus materi ini?')) return;

    database.ref('courses/' + courseId).remove().then(() => {
        const index = courses.findIndex(c => c.id === courseId);
        if (index > -1) courses.splice(index, 1);
        renderCourses();
        renderMonthButtons();
        renderAdminCourseList();
        alert('✅ Materi berhasil dihapus!');
    });
}

function renderAdminCourseList() {
    const container = document.getElementById('adminCourseList');
    if (courses.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #999; padding: 30px;">Belum ada materi</p>';
        return;
    }

    container.innerHTML = courses.map(course => `
        <div class="course-item">
            <div class="course-item-info">
                <h4>${course.icon} ${course.title}</h4>
                <p>📅 ${course.month} | ⏱️ ${course.duration} | 📊 ${course.level}</p>
                <p style="font-size: 0.85em; color: #6c757d;">🕒 ${course.uploadTime}</p>
            </div>
            <button class="btn-danger" onclick="deleteCourse(${course.id})">🗑️ Hapus</button>
        </div>
    `).join('');
}

console.log('✅ Courses module loaded');